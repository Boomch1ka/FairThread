package com.example.fairthread.ui.theme

import androidx.compose.ui.graphics.Color

val GradientStart = Color(0xFF6A11CB)
val GradientEnd = Color(0xFF2575FC)
val WhiteText = Color(0xFFFFFFFF)
val ButtonColor = Color(0xFFFFFFFF)
val ButtonTextColor = Color(0xFF2575FC)