package com.example.fairthread.model

data class User(
    val uid: String,
    val username: String,
    val email: String
)