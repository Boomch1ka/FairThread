package com.example.fairthread.ui.theme

import androidx.compose.ui.graphics.Color

val GradientStart = Color(0xFF6A11CB)
val GradientEnd = Color(0xFF2575FC)
val ButtonColor = Color(0xFF6200EE)
val ButtonTextColor = Color.White
val WhiteText = Color.White
