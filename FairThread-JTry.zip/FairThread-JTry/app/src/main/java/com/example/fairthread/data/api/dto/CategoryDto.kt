package com.example.fairthread.data.api.dto

data class CategoryDto(
    val id: String,
    val name: String,
    val iconUrl: String
)
