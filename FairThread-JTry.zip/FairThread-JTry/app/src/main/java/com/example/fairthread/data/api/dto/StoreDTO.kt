package com.example.fairthread.data.api.dto

data class StoreDto(
    val id: String,
    val name: String,
    val logoUrl: String,
    val description: String
)
